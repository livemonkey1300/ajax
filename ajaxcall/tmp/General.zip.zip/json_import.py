FORM = {
 'scheduled_date' : { 'price' : 0.0 },
 'time_scheduled' : { 'price' : 0.0 },
 'subject' : { 'price' : 0.0 },
 'description' : { 'price' : 0.0 },
 'creator' : { 'price' : 0.0 },
 'placeholder' : { 'price' : 0.0 }
}