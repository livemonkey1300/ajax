class VIRTUAL_MACHINE(models.Model):
  virtual_machine_name = models.CharField(max_length=255,default='')
  network_throughput =  models.IntegerField(default=1,validators=[MinValueValidator(1), MaxValueValidator(1000),verbose_name='Network Throughput' )

  def __str__(self):
    return self.virtual_machine_name

  def get_display(self):
    content = { 'data' : self }
    return mark_safe(render_to_string('General/MODEL_TPL/virtual_machine.html' , content ))

  class Meta:
    verbose_name = 'Virtual Machine'





### Template ####