class VIRTUAL_MACHINE_Form(forms.ModelForm):
  class Meta:
    model = VIRTUAL_MACHINE
    fields = (
      'datacenter',
      'operating_system',
      'system_disk',
      'data_disk',
      'network_throughput',
      'memory',
      'vcpu',
      'applications',
      'fully_managed'
    )