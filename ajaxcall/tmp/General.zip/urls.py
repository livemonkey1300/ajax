from django.urls import path
from django.conf.urls import url

from . import views
from . import accounts

app_name = 'General'
urlpatterns = [
    path('', views.index, name='index'),
    path('create_virtual_machine', views.create_virtual_machine, name='create_virtual_machine'),
    path('edit_virtual_machine/<int:pk>', views.edit_virtual_machine, name='edit_virtual_machine'),
    path('call', views.ajax_call, name='call'),
    path('call/<slug:form_name>/', views.ajax_call, name='call'),
    path('call/<slug:form_name>/<slug:field>', views.ajax_call, name='call'),
    path('login/', accounts.login, name='login'),
    path('signup/', accounts.signup, name='signup'),
    path('home/', accounts.home, name='home'),
]